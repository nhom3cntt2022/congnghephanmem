package quanlycasi;
/** 
*
* Observer mo ta thanh phan cua doi tuong. 
* 
*/
public interface Observer {
	 /** 
	  *
	  * update cap nhat bai hat moi. 
	  *
	  * 
	  */
	void update(String songName);
	
}
