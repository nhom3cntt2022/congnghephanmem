package quanlycasi;
/** 
*
* lop nay la lop main de hien thuc va goi chuong trinh
* 
*/
public class MySinger extends Singer {
	
	public static void main(String[] args) {
		

	}

}


